<?php

namespace Database\Factories;

use App\Models\Tata;
use Illuminate\Database\Eloquent\Factories\Factory;

class TataFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Tata::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
