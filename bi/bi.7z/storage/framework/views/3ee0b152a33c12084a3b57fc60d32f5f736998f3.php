

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
       <div class="col-md-8">
           <div class="card">
               <div class="card-header">
               Create new Publisher
               </div>
               <div class="card-body">
                 <form method="POST" action="<?php echo e(route('publisher.store')); ?>">
                  <div class="form-group">
                     <label>Title: </label>
                     <input type="text" class="form-control" name="publisher_title" value="<?php echo e(old('publisher_title')); ?>">
                     <small class="form-text text-muted">Please enter new publishers title</small>
                  </div>
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-primary">ADD</button>
               </form>
               </div>
           </div>
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bi\resources\views/publisher/create.blade.php ENDPATH**/ ?>