

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
       <div class="col-md-8">
           <div class="card">
               <div class="card-header">
               <h2>Publishers List</h2>
               
              <a href="<?php echo e(route('publisher.index', ['sort' => 'title'])); ?>">Sort by title</a>
               
                           
              <a href="<?php echo e(route('publisher.index')); ?>">Default</a>
               
               </div>
               <div class="card-body">
                <ul class="list-group">
                  <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item list-line">
                      <div>
                        <?php echo e($publisher->title); ?>

                      </div> 
                      <div class="list-line__buttons">
                        <a href="<?php echo e(route('publisher.edit',[$publisher])); ?>" class="btn btn-info">EDIT</a>
                        <form method="POST" action="<?php echo e(route('publisher.destroy', [$publisher])); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">DELETE</button>
                        </form>
                      </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
               </div>
           </div>
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bi\resources\views/publisher/index.blade.php ENDPATH**/ ?>