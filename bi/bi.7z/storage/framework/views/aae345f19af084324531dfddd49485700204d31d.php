<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<title><?php echo e($book->title); ?></title>
        <style>
            @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            src: url(<?php echo e(asset('fonts/Roboto-Regular.ttf')); ?>);
            }
            @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: bold;
            src: url(<?php echo e(asset('fonts/Roboto-Bold.ttf')); ?>);
            }
            body {
                font-family: 'Roboto';
            }
        </style>
	</head>
	<body>
        <h1><?php echo e($book->title); ?></h1>
        <h3><?php echo e($book->bookAuthor->name); ?> <?php echo e($book->bookAuthor->surname); ?></h3>
        <h4><b>Publisher:</b> <?php echo e($book->bookPublisher->title); ?></h4>
        <div><?php echo $book->about; ?></div>
	</body>
</html><?php /**PATH C:\xampp\htdocs\bi\resources\views/book/pdf.blade.php ENDPATH**/ ?>