

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
       <div class="col-md-8">
           <div class="card">
               <div class="card-header">Edit Author</div>
               <div class="card-body">
                 <form method="POST" action="<?php echo e(route('author.update', $author)); ?>" enctype="multipart/form-data">
                  <div class="form-group">
                     <label>Name: </label>
                     <input type="text" class="form-control" name="author_name" value="<?php echo e(old('author_name', $author->name)); ?>">
                     <small class="form-text text-muted">Please enter authors name</small>
                  </div>
                  <div class="form-group">
                     <label>Surname: </label>
                     <input type="text" class="form-control" name="author_surname" value="<?php echo e(old('author_surname',$author->surname)); ?>">
                     <small class="form-text text-muted">Please enter authors surname</small>
                  </div>
                  <div class="form-group">
                     <label>Portret: </label>
                     <span style="padding:8px;margin:8px;display:inline-block;">
                     <img src="<?php echo e($author->portret); ?>">
                     </span>
                     <input type="file" class="form-control" name="author_portret">
                     <small class="form-text text-muted">Please upload portret</small>
                  </div>
                     <?php echo csrf_field(); ?>
                     <button type="submit" class="btn btn-primary">EDIT</button>
                  </form>
               </div>
           </div>
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bi\resources\views/author/edit.blade.php ENDPATH**/ ?>