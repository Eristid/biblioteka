

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
       <div class="col-md-8">
           <div class="card">
               <div class="card-header">
               <h2>Books List</h2>
               <div class="make-inline">
                <form action="<?php echo e(route('book.index')); ?>" method="get" class="make-inline">
                  <div class="form-group make-inline">
                    <label>Author: </label>
                    <select class="form-control" name="author_id">
                            <option value="0"  <?php if($filterBy == 0): ?> selected <?php endif; ?>>All Authors</option>
                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($author->id); ?>" <?php if($filterBy == $author->id): ?> selected <?php endif; ?>>
                                <?php echo e($author->name); ?> <?php echo e($author->surname); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <label class="form-check-label" >Sort by title:</label>
                  <label class="form-check-label" for="sortASC">ASC</label>
                  <div class="form-group make-inline column">
                  <input type="radio" class="form-check-input" name="sort" value="asc" id="sortASC" <?php if($sortBy == 'asc'): ?> checked <?php endif; ?>>
                  </div>
                  <label class="form-check-label" for="sortDESC">DESC</label>
                  <div class="form-group make-inline column">
                  <input type="radio" class="form-check-input" name="sort" value="desc" id="sortDESC" <?php if($sortBy == 'desc'): ?> checked <?php endif; ?>>
                  </div>
                <button type="submit" class="btn btn-info">Filter</button>
                </form>
               
              <a href="<?php echo e(route('book.index')); ?>"  class="btn btn-info">Clear filter</a>
               </div>
               </div>
               <div class="card-body">
                <ul class="list-group">
                  <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item list-line">
                      <div class="list-line__books">

                        <div class="list-line__books__title">
                          <?php echo e($book->title); ?>

                        </div> 
                        <div class="list-line__books__author">
                          <?php echo e($book->bookAuthor->name); ?> <?php echo e($book->bookAuthor->surname); ?>

                        </div>
                        <div class="list-line__books__author">
                          <b>Publisher:</b> <?php echo e($book->bookPublisher->title); ?>

                        </div>
                      </div>

                      <div class="list-line__buttons">
                        <a href="<?php echo e(route('book.show',[$book])); ?>" class="btn btn-info">SHOW</a>
                        <a href="<?php echo e(route('book.edit',[$book])); ?>" class="btn btn-info">EDIT</a>
                        <a href="<?php echo e(route('book.pdf',[$book])); ?>" class="btn btn-success">PDF</a>
                        <form method="POST" action="<?php echo e(route('book.destroy', [$book])); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">DELETE</button>
                        </form>
                      </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
               </div>
           </div>
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bi\resources\views/book/index.blade.php ENDPATH**/ ?>