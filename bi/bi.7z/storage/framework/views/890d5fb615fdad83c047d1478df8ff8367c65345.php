

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
       <div class="col-md-8">
           <div class="card">
               <div class="card-header">Book <?php echo e($book->title); ?></div>
               <div class="card-body">
                <?php echo $book->about; ?>


                <a href="<?php echo e(route('book.edit',[$book])); ?>" class="btn btn-info">BOOK EDIT</a>
                <a href="<?php echo e(route('author.edit',[$book->bookAuthor])); ?>" class="btn btn-info">AUTHOR EDIT</a>
               </div>
           </div>
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bi\resources\views/book/show.blade.php ENDPATH**/ ?>