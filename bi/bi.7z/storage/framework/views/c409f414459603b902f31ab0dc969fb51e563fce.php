

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
       <div class="col-md-8">
           <div class="card">
               <div class="card-header">
               <h2>Authors List</h2>
               
              <a href="<?php echo e(route('author.index', ['sort' => 'surname'])); ?>">Sort by surname</a>
               
              <a href="<?php echo e(route('author.index', ['sort' => 'name'])); ?>">Sort by name</a>
               
              <a href="<?php echo e(route('author.index')); ?>">Default</a>
               
               </div>
               <div class="card-body">
                <ul class="list-group">
                  <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item list-line">
                      <div>
                        <img src="<?php echo e($author->portret); ?>">
                        <?php echo e($author->name); ?> <?php echo e($author->surname); ?>

                      </div> 
                      <div class="list-line__buttons">
                        <a href="<?php echo e(route('author.edit',[$author])); ?>" class="btn btn-info">EDIT</a>
                        <form method="POST" action="<?php echo e(route('author.destroy', [$author])); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">DELETE</button>
                        </form>
                      </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
               </div>
           </div>
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bi\resources\views/author/index.blade.php ENDPATH**/ ?>